#!/bin/bash
lib=$(dirname $0)/lib
$lib/uobjnew.py -l ruby "$@"
