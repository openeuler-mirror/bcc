#!/bin/bash
lib=$(dirname $0)/lib
$lib/uthreads.py -l java "$@"
