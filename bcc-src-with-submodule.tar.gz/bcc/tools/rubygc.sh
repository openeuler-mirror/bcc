#!/bin/bash
lib=$(dirname $0)/lib
$lib/ugc.py -l ruby "$@"
